

tar -czf myhome_directory.tar.gz $HOME/'Bash Scripting'

