
STRING="hello world"

echo $STRING
echo "hello"


